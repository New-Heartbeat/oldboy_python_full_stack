
# 一个py文件有两种用途
# 1、被当成程序运行
# 2、被当作模块导入

import foo
print(foo)

# print(foo.x)
# foo.change()
# print(foo.x)

# x = 1
# y = 2
# print('111')
# print('222')



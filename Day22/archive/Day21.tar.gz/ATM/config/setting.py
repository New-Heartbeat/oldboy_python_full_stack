
import os
BASE_DIR = os.path.dirname(os.path.dirname(__file__))

LOG_PATH = '%s/log/user.log' % BASE_DIR

print('正在导入m1')

# from m2 import y
# x = 'm1'

def f1():
    from m2 import y
    print(y)
x = 'm1'

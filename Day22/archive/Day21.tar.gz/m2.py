print('正在导入m2')

# from m1 import x
# y = 'm2'

def f2():
    from m1 import x

y = 'm2'

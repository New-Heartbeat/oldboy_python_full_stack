def f3():
    print('f3')